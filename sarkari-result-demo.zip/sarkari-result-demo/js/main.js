
// Simple client-side search & filters (demo)
const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => Array.from(document.querySelectorAll(sel));

function filterCards(listSel, queryInputSel, typeFilter) {
  const q = ($(queryInputSel)?.value || "").toLowerCase().trim();
  $$(listSel + " .card").forEach(card => {
    const text = card.innerText.toLowerCase();
    const isType = !typeFilter || (typeFilter === '*' ? true : card.dataset.type === typeFilter);
    card.style.display = (text.includes(q) && isType) ? "" : "none";
  });
}

// Home quick search & chips
if ($('#q')) {
  $('#q').addEventListener('input', () => filterCards('#latest-list', '#q', null));
  $$('.chip').forEach(chip => chip.addEventListener('click', () => {
    const type = chip.dataset.filter;
    filterCards('#latest-list', '#q', type === '*' ? null : type);
  }));
}

// Jobs listing filters
if ($('#job-search')) {
  const applyFilters = () => {
    const q = $('#job-search').value.toLowerCase();
    const state = $('#state-filter').value;
    const sort = $('#sort').value;
    const cards = $$('#jobs-list .card');
    cards.forEach(c => {
      const passState = !state || c.dataset.state === state;
      const passQuery = c.innerText.toLowerCase().includes(q);
      c.style.display = (passState && passQuery) ? "" : "none";
    });
    // Sort
    if (sort === 'lastdate') {
      cards.sort((a,b) => (new Date(a.dataset.lastdate) - new Date(b.dataset.lastdate)));
    } else {
      cards.sort((a,b) => b.offsetTop - a.offsetTop); // noop-ish for demo
    }
    const parent = $('#jobs-list');
    cards.forEach(c => parent.appendChild(c));
  };
  ['input','change'].forEach(evt => {
    $('#job-search').addEventListener(evt, applyFilters);
    $('#state-filter').addEventListener(evt, applyFilters);
    $('#sort').addEventListener(evt, applyFilters);
  });
}

// Small UX niceties
document.addEventListener('DOMContentLoaded', () => {
  // Add aria-current to active nav link
  const path = location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav a').forEach(a => {
    if (a.getAttribute('href').endswith(path)) {
      a.classList.add('active');
      a.setAttribute('aria-current','page');
    }
  });
});
